function onTableClick_preNavigateToPage(row, col, rowCells) {
	storeFromIndex("S_CUSTOMER_ID_0", row);
	storeFromIndex("S_CUSTOMER_PHONE_0", row);
	storeFromIndex("S_CUSTOMER_COUNTRY_0", row);
	storeFromIndex("S_CUSTOMER_ADDRESS_0", row);
	storeFromIndex("S_CUSTOMER_CITY_0", row);
	storeFromIndex("S_CUSTOMER_ZIP_CODE_0", row);
	storeFromIndex("S_CUSTOMER_COMMENTS_0", row);
	storeFromIndex("S_CUSTOMER_NAME_0", row);
	storeFromIndex("S_CUSTOMER_STATE_0", row);
	storeFromIndex("S_CUSTOMER_CREDIT_RATING_0", row);

}

